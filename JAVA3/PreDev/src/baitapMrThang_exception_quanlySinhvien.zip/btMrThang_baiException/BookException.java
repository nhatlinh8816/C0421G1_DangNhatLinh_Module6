package btMrThang_baiException;

public class BookException extends Exception {

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Not found";
	}

}
